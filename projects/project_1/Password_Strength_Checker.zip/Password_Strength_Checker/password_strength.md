# Project - Password Strength Checker
## CIS 162 - Fall 2026

Choosing a proper password is essential to keeping your data secure.  While modern tools like passkeys will eventually replace passwords, passwords are still used for a lot of applications.  In this project, we will create a (very) simple password strength checking application.

> **Note:** This application is too simple to be used for checking actual passwords. Real password strength checkers are much more complicated, check for dictionary words and variations, L33T code, commonly used sequences, etc.

## Before you begin

At this stage in our coding development, we are learning how to "think like a computer".  Our goal is to turn the logic above into Python code. You should already:

- be comfortable with printing messages
- get how to use the `input()` function to ask a user for a string
- know how to create and name a variable
- grasp how to perform math operations
- understand basic variable types (`int`, `float`, `str`, and `bool`)
- be able to write a simple `if` statement

Again, if any of these concepts are confusing to you, consult with your instructor (or go to the Student Success Center or Python Wave!).  Don't try to start the project until you understand these basics.

## Step One - Setting up your programming environment

Setting up an environment for programming can be complex.  You need to choose an editor, ensure you are using correct versions of the language you wish to code in, and acquire and setup any libraries you might need.  That is a lot to learn when you are also learning how to code.  Therefore, we have created a virtual environment for you, that includes all of the above already preinstalled and setup.  You will be able to code in the cloud, with only your Web browser.  Follow these steps to get
going:

- Create an account on [Github](https://www.github.com).  Github is a cloud-based code repository.  It is widely used in industry.  It runs off of a technology called Git Version Control.  You will learn more about Git and Github, but for now simply create your account and make sure you are logged in.

> **Note:** You will be using Github throughout your academic career, and then likely in your professional life to showcase personal projects, include information for job applications, etc.  We recommend thinking about your Github username carefully.  Professor Moore and Professor Woodring simply use their names and many others do as well.

- Once logged into Github, in the top right of the page are some icons:

    ![Github Icons](./icons.png) One is a "+" sign.  Click on that and choose "New repository".

- On the next page, you will be prompted to enter a name for the repository.  Name this one `password_strength_checker-162`.
- Ensure the visibility is "Private".  Leaving code for a course assignment "Public" allows for cheating; be sure to always set visibility to "Private" unless instructed otherwise.
- Choose the option to start with a template.  Enter `irawoodring/162-F26-Template`.  This is the template we have created for you for this project; it is setup to make programming as simple as possible for you.
- Click OK to create the repository.

    After a minute or so, you will be redirected to the homepage screen for your repository.  Here you will see a list of the files that are part of the repository, as well as a "README" document with information about the repo.  Above the file list will be a green button that says, "Code":

    ![Github Icons](./code_button.png) Click on this button.  

- A new menu will open with two tabs, "Local" and "Codespaces".  Select "Codespaces".  Then, press the button from the Codespaces menu to start the Codespace.  Your environment will open
in a new browser tab.  Allow it to fully load; you will know it has fully loaded because a pop-up will ask you if you want to trust the authors of the files in this repository.  Select "Trust Folder & Continue".  You should now be ready to begin coding!  In your browser, you should see a window that looks similar to this:

    ![VSCode Interface](./vscode_interface.png)
 

## Step Two - Coding the application

At this point, your environment should be setup and ready to go.  If it is not, consult with your instructor to get it going!

Create a file called `password_strength.py`.  At the top of the file, add the following (but fill in your values):

```python
'''
password_strength.py: A module to check the strength of a password provided by a user.

This should not be used for actual passwords; instead it is simply a coding exercise.

YOUR NAME HERE
CIS 162 - SECTION YOUR SECTION
DATE
'''
```

For all projects you turn in this semester, you should provide a header like this one.  Note the `'''` - those denote a **docstring**, or documentation string in Python.

As this is our first programming assignment on your own, we are providing a scaffold for the application's code.  The application logic will work as follows:

1. We will print a message telling the user about our app, and asking them to enter a password. It should look like:
    ```
    My Password Strength Checker
        by <YOUR NAME HERE>
    
    Enter the password to check: 
    ```

2. The app will wait for the user to type a password and press 'Enter'.  Use the `input()` function.  Store what the user entered in a string variable.
3. A score variable (an integer) should be created and the starting value set to `0`.
4. We will inspect the password string for lower-case characters.  If any are found we will add 10 to the score. Python provides a method `upper()` to convert a string to all upper-case.  We can check if the password contains lower-case characters by converting the password to all upper-case and checking if it is still the same password or not.  For example:
    ```python
    if user_password != user_password.upper():
    # If they aren't the same, some characters were converted.
    # Therefore, some were lower-case before the conversion!
    ```

5. The app will then do the same thing for upper-case characters, digits, and special characters - checking for each group one at a time. We can use the `lower()` function which converts text to all lower-case to check for upper-case characters in the same way as we checked for lower-case.  To check for digits and special characters, we will use a different method.  To check for digits, we can use the line
    ```python
    digits = any(char.isdigit() for char in password)
    ```

    This line is technically looping over every character in the string one-at-a-time and seeing if any of them are digits.  We are providing this code for you since we have not learned about looping yet.  Similarly, we can check for special characters with the line:
    ```python
    special = any(char in string.punctuation for char in password)
    ```

    Both of these lines will result in a boolean (a `True` or `False`) value, noting if the characters checked for were in the string.

    > **Note:** It is common when learning to code, or even as an advanced programmer to encounter example code that you don’t quite know what it does but can make a reasonable guess.  It is important though that you develop your skill of inference to understand any code you include in a program.  Take a moment and try to figure out what the `any()` function does.  Use the Internet and search for an explanation.  Write a summary of your conclusions as a comment above the first call to the any function.  Note what websites or tools you used to conduct this as well.  These type of notes in your own code will help you when you review months into the future… ask me how I know 😊 .

6. The string length will be checked.  Use the `len()` function. If it is greater than 8 characters, but less than 12 characters, we will add 5 to the score.  If it is 12 or more characters, we will add 10 to the score.
7. Choose five words from the [Most Popular Letter Passes List](https://github.com/danielmiessler/SecLists/blob/master/Passwords/Most-Popular-Letter-Passes.txt).  These are chunks of words that are commonly used in peoples' passwords.  They should be avoided!
8. Check (one-at-a-time) if the chunks you chose are in the password string.  Subtract 1 from the score each time one of those words is found.  Remember, you can use the syntax `word_to_check in password` in an `if`-statement.  For example:
    ```python
    if 'birthday' in password:
        score = score - 1   
    ```

9. The app will then evaluate the score.  The final score can range from 0 to 50.  Create a string called `color`, and set it to 'red'. Red would indicate a poor password.
10. If the score is over 40, change color to 'yellow'. This would indicate an ok password.
11. If the score is over 45, change color to 'green'. This would indicate a good password.
12. The app will draw an image of a meter with the color chosen, and will save the image.
13. The app will exit.

## Grading Rubric

Your project will be graded as follows:

|Criteria|Deficient (0 points)|Partially Complete (0-7 points)|Meets Expectations (10 points)|
|--------|--------------------|-------------------------------|------------------------------|
| Docstring Header | Not provided | Implemented but missing some information or formatted incorrectly. | Provided with required information and formatting. |
| Lower-case Character Check | Not implemented | Incorrectly implemented | Implemented correctly |
| Upper-case Character Check | Not implemented | Incorrectly implemented | Implemented correctly |
| Digit Check | Not implemented | Incorrectly implemented | Implemented correctly |
| Special Character Check | Not implemented | Incorrectly implemented | Implemented correctly |
| Length Check | Not implemented | Incorrectly implemented | Implemented correctly |
| Five Common Chunks Check | Not implemented | Incorrectly/Partially implemented | Implemented correctly |
| At Least 5 Comments (not counting header) | Not implemented | Partially implemented | Implemented fully |
| Produces Color Strength Meter | Not implemented | Incorrectly/Partially implemented | Implemented correctly |

This adds to 90 points.  The remaining 10 points will come from answering the following questions.  You may answer these questions in the same file you coded in, at the bottom of the file.  Put the answers in comments and be sure you number them correctly. Please answer honestly, as these help us to evaluate how the project was received.

1. What resources did you use to help you complete this project?
2. How many hours did you spend (roughly) on the project?
3. How many times did you attend office hours, the Success Center, or Python Wave?
4. What part of the project was the toughest?
5. Did you experience any issues using the Github Codespace for coding?  If so, please note the issues you experienced.
6. Why do you think we ask you to provide comments in the code?
7. What was your prior programming experience before this course (it is perfectly fine to say 'None').
8. Lookup the documentation for Python's `len()` function [here](https://docs.python.org/3/library/functions.html#len).  What can it be used on besides strings?  What will it return if a length is too large?
9. Research other techniques that are used to create a strong password.  What are three mistakes people often make when creating a password?
10. Currently, if the user enters an empty password the program still evaluates its score (though it will evaluate to 0).  What might be a better way of handling the situation when a user enters an empty password? 
